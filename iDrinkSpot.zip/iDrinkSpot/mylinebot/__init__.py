
'''
from . import views
from foodlinebot.views import *

from django.views.static import *
from django.views.generic import *
from django.views.defaults import *
'''


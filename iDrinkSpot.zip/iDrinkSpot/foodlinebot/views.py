import json, requests
import math
import urllib.parse
from django.shortcuts import render
from django.http import HttpResponse, HttpResponseBadRequest, HttpResponseForbidden
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings

from linebot import LineBotApi, WebhookParser, WebhookHandler
from linebot.exceptions import InvalidSignatureError, LineBotApiError
from linebot.models import (MessageEvent, TextSendMessage, TemplateSendMessage,
     ButtonsTemplate, MessageTemplateAction, CarouselTemplate, CarouselColumn, MessageAction,
    PostbackAction, URIAction, LocationMessage, TextComponent, BoxComponent, BubbleContainer, FlexSendMessage,PostbackTemplateAction, PostbackEvent,  QuickReply, QuickReplyButton,
)

# from .scraper import IFoodie
from .scraper import iDrink, iMenu, iItem


# 取得settings.py中的LINE Bot憑證來進行Messaging API的驗證
line_bot_api = LineBotApi(settings.LINE_CHANNEL_ACCESS_TOKEN) 
parser = WebhookParser(settings.LINE_CHANNEL_SECRET)
handler = WebhookHandler(settings.LINE_CHANNEL_SECRET)


drinkShop_options = [] # 存距離短的店名的list
drink_category =[] #特定飲料店的菜單 (第一列是店名)


Shop_name = ["CoCo都可", "珍煮丹", "迷客夏", "可不可熟成紅茶", "麻古茶坊", "五桐號WooTEA", "COMEBUY", "清心福全"]

# 搜尋飲料項目 - 咖啡
def search_coffee_items(items):
    result = []
    for item in items:
        if ("咖啡" in item[1] or "拿鐵" in item[1]):
            result.append(item)
    return result

# LineBot 回覆函式 - 咖啡
def reply_coffee_message(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    all_items = iitem.scrape()

    # 搜尋包含"咖啡"或"拿鐵"的飲料項目
    search_result = search_coffee_items(all_items)

    if len(search_result) > 0:
        reply_coffee_text = "以下是包含「咖啡」或「拿鐵」的飲料品項：\n"
        for i, result in enumerate(search_result, 1):
            reply_coffee_text += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result[1], result[2], result[3])

        quick_reply_items = [
            QuickReplyButton(action=MessageAction(label='300卡以內', text='卡路里300以內的咖啡')),
            QuickReplyButton(action=MessageAction(label='300卡以上', text='卡路里超過300的咖啡')),
            QuickReplyButton(action=MessageAction(label='400卡以上', text='卡路里超過400的咖啡')),
            QuickReplyButton(action=MessageAction(label='70元以上', text='70元以上的咖啡')),
            QuickReplyButton(action=MessageAction(label='70元以下', text='70元以下的咖啡')),
        ]

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_coffee_text, quick_reply=QuickReply(items=quick_reply_items))
        )
    else:
        reply_coffee_text = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_coffee_text)
        )

# 搜尋飲料項目 - 咖啡（卡路里在300以內）
def search_coffee_items_200k(items_200):
    result_200 = []
    for item_200 in items_200:
       if ("咖啡" in item_200[1] or "拿鐵" in item_200[1]) and int(item_200[3]) < 300:
            result_200.append(item_200)
    return result_200

# LineBot 回覆函式 - 咖啡（卡路里大於200）
def reply_coffee_message_200(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_200k = iitem.scrape()

    # 搜尋卡路里大於200的咖啡品項
    search_result = search_coffee_items_200k(items_200k)

    if len(search_result) > 0:
        # 將搜尋結果按照卡路里的升序排列
        search_result = sorted(search_result, key=lambda x: int(x[3]))
        
        reply_coffee_text_200 = "以下是卡路里大於200，小於300的咖啡品項：\n"
        for i, result_200 in enumerate(search_result, 1):
            reply_coffee_text_200 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_200[1], result_200[2], result_200[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_coffee_text_200)
        )
    else:
        reply_coffee_text_200 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_coffee_text_200)
        )

# 搜尋飲料項目 - 咖啡（卡路里大於300）
def search_coffee_items_300k(items_300):
    result_300 = []
    for item_300 in items_300:
       if ("咖啡" in item_300[1] or "拿鐵" in item_300[1]) and int(item_300[3]) > 300 and int(item_300[3]) < 400:
            result_300.append(item_300)
    return result_300

# LineBot 回覆函式 - 咖啡（卡路里大於300）
def reply_coffee_message_300(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_300k = iitem.scrape()

    # 搜尋卡路里大於500的咖啡品項
    search_result = search_coffee_items_300k(items_300k)

    if len(search_result) > 0:
        # 將搜尋結果按照卡路里的升序排列
        search_result = sorted(search_result, key=lambda x: int(x[3]))

        reply_coffee_text_300 = "以下是卡路里大於400的咖啡品項：\n"
        for i, result_300 in enumerate(search_result, 1):
            reply_coffee_text_300 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_300[1], result_300[2], result_300[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_coffee_text_300)
        )
    else:
        reply_coffee_text_300 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_coffee_text_300)
        )

# 搜尋飲料項目 - 咖啡（卡路里大於400）
def search_coffee_items_400k(items_400):
    result_400 = []
    for item_400 in items_400:
       if ("咖啡" in item_400[1] or "拿鐵" in item_400[1]) and int(item_400[3]) > 400:
            result_400.append(item_400)
    return result_400

# LineBot 回覆函式 - 咖啡（卡路里大於400）
def reply_coffee_message_400(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_400k = iitem.scrape()

    # 搜尋卡路里大於400的咖啡品項
    search_result = search_coffee_items_400k(items_400k)

    if len(search_result) > 0:
        # 將搜尋結果按照卡路里的升序排列
        search_result = sorted(search_result, key=lambda x: int(x[3]))

        reply_coffee_text_400 = "以下是卡路里大於400的咖啡品項：\n"
        for i, result_400 in enumerate(search_result, 1):
            reply_coffee_text_400 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_400[1], result_400[2], result_400[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_coffee_text_400)
        )
    else:
        reply_coffee_text_400 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_coffee_text_400)
        )

# 搜尋飲料項目 - 咖啡（價錢大於70）
def search_coffee_items_70k(items_70):
    result_70 = []
    for item_70 in items_70:
       if ("咖啡" in item_70[1] or "拿鐵" in item_70[1]) and int(item_70[2]) >= 70:
            result_70.append(item_70)
    return result_70

# LineBot 回覆函式 - 咖啡（價錢大於70）
def reply_coffee_message_70(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_70k = iitem.scrape()

    # 搜尋價錢大於70的咖啡品項
    search_result = search_coffee_items_70k(items_70k)

    if len(search_result) > 0:
        # 將搜尋結果按照價錢的升序排列
        search_result = sorted(search_result, key=lambda x: int(x[2]))

        reply_coffee_text_70 = "以下是價錢大於70的咖啡品項：\n"
        for i, result_70 in enumerate(search_result, 1):
            reply_coffee_text_70 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_70[1], result_70[2], result_70[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_coffee_text_70)
        )
    else:
        reply_coffee_text_70 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_coffee_text_70)
        )

# 搜尋飲料項目 - 咖啡（價錢小於70）
def search_coffee_items_69k(items_69k):
    result_69 = []
    for item_69 in items_69k:
       if ("咖啡" in item_69[1] or "拿鐵" in item_69[1]) and int(item_69[2]) < 70:
            result_69.append(item_69)
    return result_69

# LineBot 回覆函式 - 咖啡（價錢小於70）
def reply_coffee_message_69(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_69k = iitem.scrape()

    # 搜尋價錢小於70的咖啡品項
    search_result = search_coffee_items_69k(items_69k)

    if len(search_result) > 0:
        # 將搜尋結果按照價格的降序排列
        search_result = sorted(search_result, key=lambda x: int(x[2]))

        reply_coffee_text_69 = "以下是價錢小於70的咖啡品項：\n"
        for i, result_69 in enumerate(search_result, 1):
            reply_coffee_text_69 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_69[1], result_69[2], result_69[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_coffee_text_69)
        )
    else:
        reply_coffee_text_69 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_coffee_text_69)
        )




# 搜尋飲料項目 - 果汁
def search_juice_items(keyword, items, kcal_threshold=None):
    result = []
    for item in items:
        if ("百香" in item[1] or "柳橙" in item[1] or "冰沙" in item[1] or "葡萄" in item[1] or "芒果" in item[1] or "檸檬" in item[1] or "柳丁" in item[1]) and (kcal_threshold is None or int(item[3]) >= kcal_threshold):
            result.append(item)
    return result

# LineBot 回覆函式 - 果汁
def reply_juice_message(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items = iitem.scrape()

    # 搜尋包含"果汁"的飲料項目
    search_result = search_juice_items(user_input, items)

    if len(search_result) > 0:
        # 回覆搜尋結果的item, price, kcal
        reply_text = "以下是包含「果汁」的飲料品項：\n"
        for i, result in enumerate(search_result, 1):
            reply_text += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result[1], result[2], result[3])
        
        quick_reply_items = [
            QuickReplyButton(action=MessageAction(label='300卡以下', text='卡路里在300在以下的果汁')),
            QuickReplyButton(action=MessageAction(label='300卡以上', text='卡路里超過300的果汁')),
            QuickReplyButton(action=MessageAction(label='400卡以上', text='卡路里超過400的果汁')),
            QuickReplyButton(action=MessageAction(label='60元以上', text='60元以上的果汁')),
            QuickReplyButton(action=MessageAction(label='60元以下', text='60元以下的果汁')),
        ]
        
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_text, quick_reply=QuickReply(items=quick_reply_items))
        )
    else:
        reply_text = "抱歉，沒有找到包含「果汁」的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_text)
        )

# 搜尋飲料項目 - 果汁（卡路里大於200）
def search_juice_items_200k(items_200_j):
    result_200_j = []
    for item_200_j in items_200_j:
       if ("百香" in item_200_j[1] or "柳橙" in item_200_j[1] or "冰沙" in item_200_j[1] or "葡萄" in item_200_j[1] or "芒果" in item_200_j[1] or "檸檬" in item_200_j[1] or "柳丁" in item_200_j[1]) and int(item_200_j[3]) < 300:
            result_200_j.append(item_200_j)
    return result_200_j

# LineBot 回覆函式 - 果汁（卡路里大於200）
def reply_juice_message_200(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_200k_j = iitem.scrape()

    # 搜尋卡路里大於200的果汁品項
    search_result = search_juice_items_200k(items_200k_j)

    if len(search_result) > 0:
        # 將搜尋結果按照卡路里的升序排列
        search_result = sorted(search_result, key=lambda x: int(x[3]))

        reply_juice_text_200 = "以下是卡路里大於200，小於300的果汁品項：\n"
        for i, result_200_j in enumerate(search_result, 1):
            reply_juice_text_200 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_200_j[1], result_200_j[2], result_200_j[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_juice_text_200)
        )
    else:
        reply_juice_text_200 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_juice_text_200)
        )

# 搜尋飲料項目 - 果汁（卡路里大於300）
def search_juice_items_300k(items_300_j):
    result_300_j = []
    for item_300_j in items_300_j:
       if ("百香" in item_300_j[1] or "柳橙" in item_300_j[1] or "冰沙" in item_300_j[1] or "葡萄" in item_300_j[1] or "芒果" in item_300_j[1] or "檸檬" in item_300_j[1] or "柳丁" in item_300_j[1]) and int(item_300_j[3]) > 300 and int(item_300_j[3]) < 400:
            result_300_j.append(item_300_j)
    return result_300_j

# LineBot 回覆函式 - 果汁（卡路里大於300）
def reply_juice_message_300(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_300k_j = iitem.scrape()

    # 搜尋卡路里大於300的果汁品項
    search_result = search_juice_items_300k(items_300k_j)

    if len(search_result) > 0:
        # 將搜尋結果按照卡路里的升序排列
        search_result = sorted(search_result, key=lambda x: int(x[3]))

        reply_juice_text_300 = "以下是卡路里大於300，小於400的果汁品項：\n"
        for i, result_300_j in enumerate(search_result, 1):
            reply_juice_text_300 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_300_j[1], result_300_j[2], result_300_j[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_juice_text_300)
        )
    else:
        reply_juice_text_300 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_juice_text_300)
        )

# 搜尋飲料項目 - 果汁（卡路里大於400）
def search_juice_items_400k(items_400_j):
    result_400_j = []
    for item_400_j in items_400_j:
       if ("百香" in item_400_j[1] or "柳橙" in item_400_j[1] or "冰沙" in item_400_j[1] or "葡萄" in item_400_j[1] or "芒果" in item_400_j[1] or "檸檬" in item_400_j[1] or "柳丁" in item_400_j[1]) and int(item_400_j[3]) > 400:
            result_400_j.append(item_400_j)
    return result_400_j

# LineBot 回覆函式 - 果汁（卡路里大於400）
def reply_juice_message_400(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_400k_j = iitem.scrape()

    # 搜尋卡路里大於400的果汁品項
    search_result = search_juice_items_400k(items_400k_j)

    if len(search_result) > 0:
        # 將搜尋結果按照卡路里的升序排列
        search_result = sorted(search_result, key=lambda x: int(x[3]))

        reply_juice_text_400 = "以下是卡路里大於400的果汁品項：\n"
        for i, result_400_j in enumerate(search_result, 1):
            reply_juice_text_400 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_400_j[1], result_400_j[2], result_400_j[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_juice_text_400)
        )
    else:
        reply_juice_text_400 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_juice_text_400)
        )

# 搜尋飲料項目 - 果汁（價錢大於60）
def search_juice_items_60k(items_60_j):
    result_60_j = []
    for item_60_j in items_60_j:
      if ("百香" in item_60_j[1] or "柳橙" in item_60_j[1] or "冰沙" in item_60_j[1] or "葡萄" in item_60_j[1] or "芒果" in item_60_j[1] or "檸檬" in item_60_j[1] or "柳丁" in item_60_j[1]) and int(item_60_j[2]) >= 60:
            result_60_j.append(item_60_j)
    return result_60_j

# LineBot 回覆函式 - 果汁（價錢大於60）
def reply_juice_message_60(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_60k_j = iitem.scrape()

    # 搜尋價錢大於60的果汁品項
    search_result = search_juice_items_60k(items_60k_j)

    if len(search_result) > 0:
        # 將搜尋結果按照價格的降序排列
        search_result = sorted(search_result, key=lambda x: int(x[2]))

        reply_juice_text_60 = "以下是價錢大於60的果汁品項：\n"
        for i, result_60_j in enumerate(search_result, 1):
            reply_juice_text_60 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_60_j[1], result_60_j[2], result_60_j[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_juice_text_60)
        )
    else:
        reply_juice_text_60 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_juice_text_60)
        )

# 搜尋飲料項目 - 果汁（價錢小於60）
def search_juice_items_59k(items_59_j):
    result_59_j = []
    for item_59_j in items_59_j:
      if ("百香" in item_59_j[1] or "柳橙" in item_59_j[1] or "冰沙" in item_59_j[1] or "葡萄" in item_59_j[1] or "芒果" in item_59_j[1] or "檸檬" in item_59_j[1] or "柳丁" in item_59_j[1]) and int(item_59_j[2]) < 60:
            result_59_j.append(item_59_j)
    return result_59_j

# LineBot 回覆函式 - 果汁（價錢小於60）
def reply_juice_message_59(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_59k_j = iitem.scrape()

    # 搜尋價錢大於60的果汁品項
    search_result = search_juice_items_59k(items_59k_j)

    if len(search_result) > 0:
        # 將搜尋結果按照價格的降序排列
        search_result = sorted(search_result, key=lambda x: int(x[2]))
        
        reply_juice_text_59 = "以下是價錢小於60的果汁品項：\n"
        for i, result_59_j in enumerate(search_result, 1):
            reply_juice_text_59 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_59_j[1], result_59_j[2], result_59_j[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_juice_text_59)
        )
    else:
        reply_juice_text_59 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_juice_text_59)
        )




# 搜尋飲料項目 - 奶茶
def search_milktea_items(keyword, items, kcal_threshold=None):
    result = []
    for item in items:
        if ("奶茶" in item[1]) and (kcal_threshold is None or int(item[3]) >= kcal_threshold):
            result.append(item)
    return result

# LineBot 回覆函式 - 奶茶
def reply_milktea_message(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items = iitem.scrape()

    # 搜尋包含"奶茶"的飲料項目
    search_result = search_milktea_items(user_input, items)

    if len(search_result) > 0:
        # 回覆搜尋結果的item, price, kcal
        reply_text = "以下是包含「奶茶」的飲料品項：\n"
        for i, result in enumerate(search_result, 1):
            reply_text += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result[1], result[2], result[3])
        
        quick_reply_items = [
            QuickReplyButton(action=MessageAction(label='500卡以內', text='卡路里在500以內的奶茶')),
            QuickReplyButton(action=MessageAction(label='500卡以上', text='卡路里超過500的奶茶')),
            QuickReplyButton(action=MessageAction(label='600卡以上', text='卡路里超過600的奶茶')),
            QuickReplyButton(action=MessageAction(label='60元以上', text='60元以上的奶茶')),
            QuickReplyButton(action=MessageAction(label='60元以下', text='60元以下的奶茶')),
        ]
        
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_text, quick_reply=QuickReply(items=quick_reply_items))
        )
    else:
        reply_text = "抱歉，沒有找到包含「奶茶」的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_text)
        )

# 搜尋飲料項目 - 奶茶（卡路里在500以內）
def search_milktea_items_400k(items_400_m):
    result_400_m = []
    for item_400_m in items_400_m:
       if ("奶茶" in item_400_m[1]) and int(item_400_m[3]) < 500:
            result_400_m.append(item_400_m)
    return result_400_m

# LineBot 回覆函式 - 奶茶（卡路里在500以內）
def reply_milktea_message_400(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_400k_m = iitem.scrape()

    # 搜尋卡路里大於400的奶茶品項
    search_result = search_milktea_items_400k(items_400k_m)

    if len(search_result) > 0:
        # 將搜尋結果按照卡路里的升序排列
        search_result = sorted(search_result, key=lambda x: int(x[3]))

        reply_milktea_text_400 = "以下是卡路里在500以內的奶茶品項：\n"
        for i, result_400_m in enumerate(search_result, 1):
            reply_milktea_text_400 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_400_m[1], result_400_m[2], result_400_m[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_milktea_text_400)
        )
    else:
        reply_milktea_text_400 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_milktea_text_400)
        )

# 搜尋飲料項目 - 奶茶（卡路里大於500）
def search_milktea_items_500k(items_500_m):
    result_500_m = []
    for item_500_m in items_500_m:
       if ("奶茶" in item_500_m[1]) and int(item_500_m[3]) >= 500 and int(item_500_m[3]) < 600:
            result_500_m.append(item_500_m)
    return result_500_m

# LineBot 回覆函式 - 奶茶（卡路里大於500）
def reply_milktea_message_500(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_500k_m = iitem.scrape()

    # 搜尋卡路里大於500的奶茶品項
    search_result = search_milktea_items_500k(items_500k_m)

    if len(search_result) > 0:
        # 將搜尋結果按照卡路里的升序排列
        search_result = sorted(search_result, key=lambda x: int(x[3]))

        reply_milktea_text_500 = "以下是卡路里大於500的奶茶品項：\n"
        for i, result_500_m in enumerate(search_result, 1):
            reply_milktea_text_500 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_500_m[1], result_500_m[2], result_500_m[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_milktea_text_500)
        )
    else:
        reply_milktea_text_500 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_milktea_text_500)
        )

# 搜尋飲料項目 - 奶茶（卡路里大於600）
def search_milktea_items_600k(items_600_m):
    result_600_m = []
    for item_600_m in items_600_m:
       if ("奶茶" in item_600_m[1]) and int(item_600_m[3]) > 600:
            result_600_m.append(item_600_m)
    return result_600_m

# LineBot 回覆函式 - 奶茶（卡路里大於600）
def reply_milktea_message_600(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_600k_m = iitem.scrape()

    # 搜尋卡路里大於600的奶茶品項
    search_result = search_milktea_items_600k(items_600k_m)

    if len(search_result) > 0:
        # 將搜尋結果按照卡路里的升序排列
        search_result = sorted(search_result, key=lambda x: int(x[3]))

        reply_milktea_text_600 = "以下是卡路里大於600的奶茶品項：\n"
        for i, result_600_m in enumerate(search_result, 1):
            reply_milktea_text_600 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_600_m[1], result_600_m[2], result_600_m[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_milktea_text_600)
        )
    else:
        reply_milktea_text_600 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_milktea_text_600)
        )

# 搜尋飲料項目 - 奶茶（價錢大於60）
def search_milktea_items_60k(items_60_m):
    result_60_m = []
    for item_60_m in items_60_m:
       if ("奶茶" in item_60_m[1]) and int(item_60_m[2]) >= 60:
            result_60_m.append(item_60_m)
    return result_60_m

# LineBot 回覆函式 - 奶茶（價錢大於60）
def reply_milktea_message_60(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_60k_m = iitem.scrape()

    # 搜尋價錢大於60的奶茶品項
    search_result = search_milktea_items_60k(items_60k_m)

    if len(search_result) > 0:
        reply_milktea_text_60 = "以下是價錢大於60的奶茶品項：\n"
        for i, result_60_m in enumerate(search_result, 1):
            # 將搜尋結果按照價格的降序排列
            search_result = sorted(search_result, key=lambda x: int(x[2]))

            reply_milktea_text_60 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_60_m[1], result_60_m[2], result_60_m[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_milktea_text_60)
        )
    else:
        reply_milktea_text_60 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_milktea_text_60)
        )

# 搜尋飲料項目 - 奶茶（價錢小於60）
def search_milktea_items_59k(items_59_m):
    result_59_m = []
    for item_59_m in items_59_m:
       if ("奶茶" in item_59_m[1]) and int(item_59_m[2]) < 60:
            result_59_m.append(item_59_m)
    return result_59_m

# LineBot 回覆函式 - 奶茶（價錢小於60）
def reply_milktea_message_59(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_59k_m = iitem.scrape()

    # 搜尋價錢大於59的奶茶品項
    search_result = search_milktea_items_59k(items_59k_m)

    if len(search_result) > 0:
        reply_milktea_text_59 = "以下是價錢小於60的奶茶品項：\n"
        for i, result_59_m in enumerate(search_result, 1):
            # 將搜尋結果按照價格的降序排列
            search_result = sorted(search_result, key=lambda x: int(x[2]))
            
            reply_milktea_text_59 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_59_m[1], result_59_m[2], result_59_m[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_milktea_text_59)
        )
    else:
        reply_milktea_text_59 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_milktea_text_59)
        )




# 搜尋飲料項目 - 綠茶
def search_greentea_items(keyword, items, kcal_threshold=None):
    result = []
    for item in items:
        if ("綠茶" in item[1]) and (kcal_threshold is None or int(item[3]) >= kcal_threshold):
            result.append(item)
    return result

# LineBot 回覆函式 - 綠茶
def reply_greentea_message(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items = iitem.scrape()

    # 搜尋包含"綠茶"的飲料項目
    search_result = search_greentea_items(user_input, items)

    if len(search_result) > 0:
        # 回覆搜尋結果的item, price, kcal
        reply_text = "以下是包含「綠茶」的飲料品項：\n"
        for i, result in enumerate(search_result, 1):
            reply_text += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result[1], result[2], result[3])
        
        quick_reply_items = [
            QuickReplyButton(action=MessageAction(label='大約100卡', text='卡路里大約100的綠茶')),
            QuickReplyButton(action=MessageAction(label='200卡以上', text='卡路里超過200的綠茶')),
            QuickReplyButton(action=MessageAction(label='300卡以上', text='卡路里超過300的綠茶')),
            QuickReplyButton(action=MessageAction(label='50元以上', text='50元以上的綠茶')),
            QuickReplyButton(action=MessageAction(label='50元以下', text='50元以下的綠茶')),
        ]
        
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_text, quick_reply=QuickReply(items=quick_reply_items))
        )
    else:
        reply_text = "抱歉，沒有找到包含「綠茶」的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_text)
        )

# 搜尋飲料項目 - 綠茶（卡路里小於等於100和100~200之間）
def search_greentea_items_100k(items_100_g):
    result_100_g = []
    for item_100_g in items_100_g:
        if "綠茶" in item_100_g[1] and int(item_100_g[3]) < 200:
            result_100_g.append(item_100_g)
    return result_100_g

# LineBot 回覆函式 - 綠茶（卡路里大於100）
def reply_greentea_message_100(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_100k_g = iitem.scrape()

    # 搜尋卡路里大於100的綠茶品項
    search_result = search_greentea_items_100k(items_100k_g)

    if len(search_result) > 0:
        # 將搜尋結果按照卡路里的升序排列
        search_result = sorted(search_result, key=lambda x: int(x[3]))

        reply_greentea_text_100 = "以下是卡路里大於100的綠茶品項：\n"
        for i, result_100_g in enumerate(search_result, 1):
            reply_greentea_text_100 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_100_g[1], result_100_g[2], result_100_g[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_greentea_text_100)
        )
    else:
        reply_greentea_text_100 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_greentea_text_100)
        )

# 搜尋飲料項目 - 綠茶（卡路里大於200）
def search_greentea_items_200k(items_200_g):
    result_200_g = []
    for item_200_g in items_200_g:
       if ("綠茶" in item_200_g[1]) and int(item_200_g[3]) > 200 and int(item_200_g[3]) < 300:
            result_200_g.append(item_200_g)
    return result_200_g

# LineBot 回覆函式 - 綠茶（卡路里大於200）
def reply_greentea_message_200(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_200k_g = iitem.scrape()

    # 搜尋卡路里大於200的綠茶品項
    search_result = search_greentea_items_200k(items_200k_g)

    if len(search_result) > 0:
        # 將搜尋結果按照卡路里的升序排列
        search_result = sorted(search_result, key=lambda x: int(x[3]))

        reply_greentea_text_200 = "以下是卡路里大於200的綠茶品項：\n"
        for i, result_200_g in enumerate(search_result, 1):
            reply_greentea_text_200 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_200_g[1], result_200_g[2], result_200_g[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_greentea_text_200)
        )
    else:
        reply_greentea_text_200 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_greentea_text_200)
        )

# 搜尋飲料項目 - 綠茶（卡路里大於300）
def search_greentea_items_300k(items_300_g):
    result_300_g = []
    for item_300_g in items_300_g:
       if ("綠茶" in item_300_g[1]) and int(item_300_g[3]) >= 300:
            result_300_g.append(item_300_g)
    return result_300_g

# LineBot 回覆函式 - 綠茶（卡路里大於300）
def reply_greentea_message_300(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_300k_g = iitem.scrape()

    # 搜尋卡路里大於300的綠茶品項
    search_result = search_greentea_items_300k(items_300k_g)

    if len(search_result) > 0:
        # 將搜尋結果按照卡路里的升序排列
        search_result = sorted(search_result, key=lambda x: int(x[3]))

        reply_greentea_text_300 = "以下是卡路里大於300的綠茶品項：\n"
        for i, result_300_g in enumerate(search_result, 1):
            reply_greentea_text_300 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_300_g[1], result_300_g[2], result_300_g[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_greentea_text_300)
        )
    else:
        reply_greentea_text_300 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_greentea_text_300)
        )

# 搜尋飲料項目 - 綠茶（價錢大於50）
def search_greentea_items_50k(items_50_g):
    result_50_g = []
    for item_50_g in items_50_g:
       if ("綠茶" in item_50_g[1]) and int(item_50_g[2]) >= 50:
            result_50_g.append(item_50_g)
    return result_50_g

# LineBot 回覆函式 - 綠茶（價錢大於50）
def reply_greentea_message_50(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_50k_g = iitem.scrape()

    # 搜尋價錢大於50的綠茶品項
    search_result = search_greentea_items_50k(items_50k_g)

    if len(search_result) > 0:
        # 將搜尋結果按照價格的降序排列
        search_result = sorted(search_result, key=lambda x: int(x[2]))

        reply_greentea_text_50 = "以下是價錢大於50的綠茶品項：\n"
        for i, result_50_g in enumerate(search_result, 1):
            reply_greentea_text_50 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_50_g[1], result_50_g[2], result_50_g[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_greentea_text_50)
        )
    else:
        reply_greentea_text_50 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_greentea_text_50)
        )

# 搜尋飲料項目 - 綠茶（價錢小於50）
def search_greentea_items_49k(items_49_g):
    result_49_g = []
    for item_49_g in items_49_g:
       if ("綠茶" in item_49_g[1]) and int(item_49_g[2]) < 50:
            result_49_g.append(item_49_g)
    return result_49_g

# LineBot 回覆函式 - 綠茶（價錢小於50）
def reply_greentea_message_49(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_49k_g = iitem.scrape()

    # 搜尋價錢大於50的綠茶品項
    search_result = search_greentea_items_49k(items_49k_g)

    if len(search_result) > 0:
        # 將搜尋結果按照價格的降序排列
        search_result = sorted(search_result, key=lambda x: int(x[2]))

        reply_greentea_text_49 = "以下是價錢小於50的綠茶品項：\n"
        for i, result_49_g in enumerate(search_result, 1):
            reply_greentea_text_49 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_49_g[1], result_49_g[2], result_49_g[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_greentea_text_49)
        )
    else:
        reply_greentea_text_49 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_greentea_text_49)
        )






# 搜尋飲料項目 - 紅茶
def search_blacktea_items(keyword, items, kcal_threshold=None):
    result = []
    for item in items:
        if ("紅茶" in item[1]) and (kcal_threshold is None or int(item[3]) >= kcal_threshold):
            result.append(item)
    return result

# LineBot 回覆函式 - 紅茶
def reply_blacktea_message(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items = iitem.scrape()

    # 搜尋包含"紅茶"的飲料項目
    search_result = search_blacktea_items(user_input, items)

    if len(search_result) > 0:
        # 回覆搜尋結果的item, price, kcal
        reply_text = "以下是包含「紅茶」的飲料品項：\n"
        for i, result in enumerate(search_result, 1):
            reply_text += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result[1], result[2], result[3])
        
        quick_reply_items = [
            QuickReplyButton(action=MessageAction(label='200卡以下', text='卡路里大約200的紅茶')),
            QuickReplyButton(action=MessageAction(label='200卡以上', text='卡路里超過200的紅茶')),
            QuickReplyButton(action=MessageAction(label='300卡以上', text='卡路里超過300的紅茶')),
            QuickReplyButton(action=MessageAction(label='400卡以上', text='卡路里超過400的紅茶')),
            QuickReplyButton(action=MessageAction(label='50元以上', text='50元以上的紅茶')),
            QuickReplyButton(action=MessageAction(label='50元以下', text='50元以下的紅茶')),
        ]
        
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_text, quick_reply=QuickReply(items=quick_reply_items))
        )
    else:
        reply_text = "抱歉，沒有找到包含「紅茶」的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_text)
        )

# 搜尋飲料項目 - 紅茶（卡路里小於等於100和100~200之間）
def search_blacktea_items_100k(items_100_b):
    result_100_b = []
    for item_100_b in items_100_b:
        if "紅茶" in item_100_b[1] and int(item_100_b[3]) < 200:
            result_100_b.append(item_100_b)
    return result_100_b

# LineBot 回覆函式 - 紅茶（卡路里大於100）
def reply_blacktea_message_100(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_100k_b = iitem.scrape()

    # 搜尋卡路里大於100的紅茶品項
    search_result = search_blacktea_items_100k(items_100k_b)

    if len(search_result) > 0:
        # 將搜尋結果按照卡路里的升序排列
        search_result = sorted(search_result, key=lambda x: int(x[3]))

        reply_blacktea_text_100 = "以下是卡路里小於200的紅茶品項：\n"
        for i, result_100_b in enumerate(search_result, 1):
            reply_blacktea_text_100 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_100_b[1], result_100_b[2], result_100_b[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_blacktea_text_100)
        )
    else:
        reply_blacktea_text_100 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_blacktea_text_100)
        )

# 搜尋飲料項目 - 紅茶（卡路里大於200）
def search_blacktea_items_200k(items_200_b):
    result_200_b = []
    for item_200_b in items_200_b:
        if "紅茶" in item_200_b[1] and int(item_200_b[3]) >= 200 and int(item_200_b[3]) < 300:
            result_200_b.append(item_200_b)
    return result_200_b

# LineBot 回覆函式 - 紅茶（卡路里大於200）
def reply_blacktea_message_200(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_200k_b = iitem.scrape()

    # 搜尋卡路里大於200的紅茶品項
    search_result = search_blacktea_items_200k(items_200k_b)

    if len(search_result) > 0:
        # 將搜尋結果按照卡路里的升序排列
        search_result = sorted(search_result, key=lambda x: int(x[3]))

        reply_blacktea_text_200 = "以下是卡路里大於200的紅茶品項：\n"
        for i, result_200_b in enumerate(search_result, 1):
            reply_blacktea_text_200 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_200_b[1], result_200_b[2], result_200_b[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_blacktea_text_200)
        )
    else:
        reply_blacktea_text_200 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_blacktea_text_200)
        )

# 搜尋飲料項目 - 紅茶（卡路里大於300）
def search_blacktea_items_300k(items_300_b):
    result_300_b = []
    for item_300_b in items_300_b:
        if "紅茶" in item_300_b[1] and int(item_300_b[3]) >= 300 and int(item_300_b[3]) < 400:
            result_300_b.append(item_300_b)
    return result_300_b

# LineBot 回覆函式 - 紅茶（卡路里大於300）
def reply_blacktea_message_300(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_300k_b = iitem.scrape()

    # 搜尋卡路里大於300的紅茶品項
    search_result = search_blacktea_items_300k(items_300k_b)

    if len(search_result) > 0:
        # 將搜尋結果按照卡路里的升序排列
        search_result = sorted(search_result, key=lambda x: int(x[3]))

        reply_blacktea_text_300 = "以下是卡路里大於300的紅茶品項：\n"
        for i, result_300_b in enumerate(search_result, 1):
            reply_blacktea_text_300 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_300_b[1], result_300_b[2], result_300_b[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_blacktea_text_300)
        )
    else:
        reply_blacktea_text_300 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_blacktea_text_300)
        )

# 搜尋飲料項目 - 紅茶（卡路里大於400）
def search_blacktea_items_400k(items_400_b):
    result_400_b = []
    for item_400_b in items_400_b:
        if "紅茶" in item_400_b[1] and int(item_400_b[3]) >= 400:
            result_400_b.append(item_400_b)
    return result_400_b

# LineBot 回覆函式 - 紅茶（卡路里大於400）
def reply_blacktea_message_400(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_400k_b = iitem.scrape()

    # 搜尋卡路里大於400的紅茶品項
    search_result = search_blacktea_items_400k(items_400k_b)

    if len(search_result) > 0:
        # 將搜尋結果按照卡路里的升序排列
        search_result = sorted(search_result, key=lambda x: int(x[3]))

        reply_blacktea_text_400 = "以下是卡路里大於400的紅茶品項：\n"
        for i, result_400_b in enumerate(search_result, 1):
            reply_blacktea_text_400 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_400_b[1], result_400_b[2], result_400_b[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_blacktea_text_400)
        )
    else:
        reply_blacktea_text_400 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_blacktea_text_400)
        )

# 搜尋飲料項目 - 紅茶（價錢大於50）
def search_blacktea_items_50k(items_50_b):
    result_50_b = []
    for item_50_b in items_50_b:
       if ("紅茶" in item_50_b[1]) and int(item_50_b[2]) >= 50:
            result_50_b.append(item_50_b)
    return result_50_b

# LineBot 回覆函式 - 紅茶（價錢大於50）
def reply_blacktea_message_50(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_50k_b = iitem.scrape()

    # 搜尋價錢大於50的紅茶品項
    search_result = search_blacktea_items_50k(items_50k_b)

    if len(search_result) > 0:
        # 將搜尋結果按照價格的降序排列
        search_result = sorted(search_result, key=lambda x: int(x[2]))

        reply_blacktea_text_50 = "以下是價錢大於50的紅茶品項：\n"
        for i, result_50_b in enumerate(search_result, 1):
            reply_blacktea_text_50 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_50_b[1], result_50_b[2], result_50_b[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_blacktea_text_50)
        )
    else:
        reply_blacktea_text_50 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_blacktea_text_50)
        )

# 搜尋飲料項目 - 紅茶（價錢小於50）
def search_blacktea_items_49k(items_49_b):
    result_49_b = []
    for item_49_b in items_49_b:
       if ("紅茶" in item_49_b[1]) and int(item_49_b[2]) < 50:
            result_49_b.append(item_49_b)
    return result_49_b

# LineBot 回覆函式 - 紅茶（價錢小於50）
def reply_blacktea_message_49(event):
    user_input = event.message.text  # 使用者輸入的訊息

    # 建立 iItem 物件並執行爬蟲
    iitem = iItem()
    items_49k_b = iitem.scrape()

    # 搜尋價錢小於50的紅茶品項
    search_result = search_blacktea_items_49k(items_49k_b)

    if len(search_result) > 0:
        # 將搜尋結果按照價格的降序排列
        search_result = sorted(search_result, key=lambda x: int(x[2]))

        reply_blacktea_text_49 = "以下是價錢小於50的紅茶品項：\n"
        for i, result_49_b in enumerate(search_result, 1):
            reply_blacktea_text_49 += "\n{}. 飲料品項: {}\n   價格: {}\n   卡路里: {}\n".format(i, result_49_b[1], result_49_b[2], result_49_b[3])

        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_blacktea_text_49)
        )
    else:
        reply_blacktea_text_49 = "抱歉，沒有找到符合搜尋條件的飲料品項。"
        line_bot_api.reply_message(
            event.reply_token,
            TextSendMessage(text=reply_blacktea_text_49)
        )
















#讀取飲料細項
def get_drink_item(split_text):

    aa = iMenu(split_text[0]) #爬指定飲料店的菜單
    category =[]

    for type, item, price, kcal in aa.scrape():
        TYPE = type
        ITEM = item
        PRICE = price
        KCAL = kcal
        category.append((TYPE, ITEM, PRICE, KCAL))
    new_category = [] 
    for i in range(0, len(category)):
        new_category.append({
            #'shop': category[i][0],
            'type': category[i][0],
            'item': category[i][1],
            'price': category[i][2],
            'kcal': category[i][3]
        })

    output_str = split_text[0] + "的" + split_text[1] + "有:"
    count=1
    for i in range(0, len(category)):
        if split_text[1] == new_category[i]['type']:
            print("shop: ", split_text[0], "type: ", new_category[i]['type'], "item: ", new_category[i]['item'], "price: ", new_category[i]['price'], "kcal: ", new_category[i]['kcal'])
            #output_str += split_text[0], drink_category[i]['type'], drink_category[i]['item'], drink_category[i]['price'], drink_category[i]['kcal']
            output_str += ' '.join(["\n", str(count), ".", new_category[i]['item'], " /$", new_category[i]['price'], "/", new_category[i]['kcal'], "kcal"])

            count+=1

        #else:
        #    print("查無品項")
    return output_str
    


# 特定飲料店的菜單，t為使用者的輸入
def get_drink_category(t):
    aa = iMenu(t) #爬蟲
    category =[]

    for type, item, price, kcal in aa.scrape():
        TYPE = type
        ITEM = item
        PRICE = price
        KCAL = kcal
        category.append((t,TYPE, ITEM, PRICE, KCAL))
    for i in range(0, len(category)):
        drink_category.append({
            'shop': category[i][0],
            'type': category[i][1],
            'item': category[i][2],
            'price': category[i][3],
            'kcal': category[i][4]
        })
    return drink_category
    

# 傳送特定飲料店的大種類 (不重複)
def send_category_of_menu(category):
    columns=[]
    unique_types = get_unique_types(category)
    shop = drink_category[0]['shop']

    for option in unique_types:
        
        column = CarouselColumn(
            title = option['type'],
            text = shop + "   Try it!!",
            actions = [ #action最多只能添加三個
                MessageAction(
                label = '點我看 '+option['type'], #顯示在按鈕上的文字
                text = shop + ", " + option['type'] #顯示在聊天室的文字
                )
            ]
        )
        columns.append(column)
        # 创建 CarouselTemplate，并指定 columns 参数为上述列表
        carousel_template = CarouselTemplate(columns=columns)
                        
        # 使用上述 CarouselTemplate 创建 TemplateSendMessage
        template_message = TemplateSendMessage(
            alt_text='CarouselTemplate',
            template=carousel_template
        )
    return template_message



@csrf_exempt
def callback(request):
 
    if request.method == 'POST':

        # 獲取 request 的內容，這邊假設為 JSON 格式
        body = request.body.decode('utf-8')
        # 解析 JSON
        events = json.loads(body)['events']

        # 逐個處理事件
        signature = request.META['HTTP_X_LINE_SIGNATURE']
        # events = parser.parse(body, signature)  # 傳入的事件
        # print("event的細節: ", events)

        try:
            events = parser.parse(body, signature)  # 傳入的事件
            # print("111 ", events) #印出事件 爬蟲part
        except InvalidSignatureError:
            # abort(400)
            return HttpResponseForbidden()
        except LineBotApiError:
            return HttpResponseBadRequest()
        
        for event in events:
            if isinstance(event, MessageEvent):  # 如果有訊息事件
                print("進入訊息事件")                        

                # 如果傳入的是文字訊息
                if event.message.type == 'text':
                    text = event.message.text

                    if text == "我想喝飲料❗❗❗":
                        line_bot_api.reply_message(
                            event.reply_token,
                            TextSendMessage(text="歡迎使用iDrinkSpot!!! \n請傳送位置資訊~~~")
                        )

                    elif text == "推薦飲料":
                        line_bot_api.reply_message(
                            event.reply_token,
                            FlexSendMessage(
                                alt_text="請選擇一個選項：",
                                contents={
                                    "type": "bubble",
                                    "hero": {
                                        "type": "image",
                                        "url": "https://i.pinimg.com/564x/90/d8/fc/90d8fc35443e896385f1da04cf7909f4.jpg",
                                        "size": "full",
                                        "aspectRatio": "12:12",
                                        "aspectMode": "cover"
                                    },
                                    "body": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                        {
                                            "type": "text",
                                            "text": "喜歡喝什麼類型的飲料？",
                                            "weight": "bold",
                                            "color": "#000000",
                                            "size": "md",
                                            "align": "start"
                                        }
                                        ]
                                    },

                                    "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "button",
                                                "action": {
                                                    "type": "message",
                                                    "label": "果汁",
                                                    "text": "果汁"
                                                }
                                            },
                                            {
                                                "type": "button",
                                                "action": {
                                                    "type": "message",
                                                    "label": "茶",
                                                    "text": "茶"
                                                }
                                            },
                                            {
                                                "type": "button",
                                                "action": {
                                                    "type": "message",
                                                    "label": "咖啡",
                                                    "text": "咖啡"
                                                }
                                            }
                                        ]
                                    }
                                }
                            )
                        )
                    elif text == "茶":
                        line_bot_api.reply_message(
                            event.reply_token,
                            FlexSendMessage(
                                alt_text="請選擇一個選項：",
                                contents={
                                    "type": "bubble",
                                    "hero": {
                                        "type": "image",
                                        "url": "https://i.pinimg.com/564x/3b/7a/ec/3b7aece087795f204cfca4dd97f551d4.jpg",
                                        "size": "full",
                                        "aspectRatio": "10:10",
                                        "aspectMode": "cover"
                                    },
                                    "body": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "contents": [
                                        {
                                            "type": "text",
                                            "text": "喜歡喝什麼類型的茶？",
                                            "weight": "bold",
                                            "color": "#000000",
                                            "size": "md",
                                            "align": "start"
                                        }
                                        ]
                                    },

                                    "footer": {
                                        "type": "box",
                                        "layout": "vertical",
                                        "spacing": "sm",
                                        "contents": [
                                            {
                                                "type": "button",
                                                "action": {
                                                    "type": "message",
                                                    "label": "奶茶",
                                                    "text": "奶茶"
                                                }
                                            },
                                            {
                                                "type": "button",
                                                "action": {
                                                    "type": "message",
                                                    "label": "綠茶",
                                                    "text": "綠茶"
                                                }
                                            },
                                            {
                                                "type": "button",
                                                "action": {
                                                    "type": "message",
                                                    "label": "紅茶",
                                                    "text": "紅茶"
                                                }
                                            }
                                        ]
                                    }
                                }
                            )
                        )
                    elif text == "咖啡":
                        reply_coffee_message(event)

                    elif text == "紅茶":
                        reply_blacktea_message(event)

                    elif text == "綠茶":
                        reply_greentea_message(event)

                    elif text == "奶茶":
                        reply_milktea_message(event)

                    elif text == "果汁":
                        reply_juice_message(event)

                    # 咖啡篩選
                    elif text == "卡路里300以內的咖啡":
                        reply_coffee_message_200(event)
                    elif text == "卡路里超過300的咖啡":
                        reply_coffee_message_300(event)
                    elif text == "卡路里超過400的咖啡":
                        reply_coffee_message_400(event)
                    elif text == "70元以上的咖啡":
                        reply_coffee_message_70(event)
                    elif text == "70元以下的咖啡":
                        reply_coffee_message_69(event)

                    # 果汁篩選
                    elif text == "卡路里在300在以下的果汁":
                        reply_juice_message_200(event)
                    elif text == "卡路里超過300的果汁":
                        reply_juice_message_300(event)
                    elif text == "卡路里超過400的果汁":
                        reply_juice_message_400(event)
                    elif text == "60元以上的果汁":
                        reply_juice_message_60(event)
                    elif text == "60元以下的果汁":
                        reply_juice_message_59(event)

                    # 奶茶篩選
                    elif text == "卡路里在500以內的奶茶":
                        reply_milktea_message_400(event)
                    elif text == "卡路里超過500的奶茶":
                        reply_milktea_message_500(event)
                    elif text == "卡路里超過600的奶茶":
                        reply_milktea_message_600(event)
                    elif text == "60元以上的奶茶":
                        reply_milktea_message_60(event)
                    elif text == "60元以下的奶茶":
                        reply_milktea_message_59(event)

                    # 綠茶篩選
                    elif text == "卡路里大約100的綠茶":
                        reply_greentea_message_100(event)
                    elif text == "卡路里超過200的綠茶":
                        reply_greentea_message_200(event)
                    elif text == "卡路里超過300的綠茶":
                        reply_greentea_message_300(event)
                    elif text == "50元以上的綠茶":
                        reply_greentea_message_50(event)
                    elif text == "50元以下的綠茶":
                        reply_greentea_message_49(event)

                    # 紅茶篩選
                    elif text == "卡路里大約200的紅茶":
                        reply_blacktea_message_100(event)
                    elif text == "卡路里超過200的紅茶":
                        reply_blacktea_message_200(event)
                    elif text == "卡路里超過300的紅茶":
                        reply_blacktea_message_300(event)
                    elif text == "卡路里超過400的紅茶":
                        reply_blacktea_message_400(event)
                    elif text == "50元以上的紅茶":
                        reply_blacktea_message_50(event)
                    elif text == "50元以下的紅茶":
                        reply_blacktea_message_49(event)


                    elif text in Shop_name:  # 如果輸入的是店名
                        drink_category.clear()
                        category = get_drink_category(text) # 傳送飲料店名稱，得到大項目

                        #顯示種類的選單
                        line_bot_api.reply_message(
                            event.reply_token,
                            send_category_of_menu(category)# 輸入大項目，顯示不重複的飲料type
                        )
                    else:
                        sp_text= text.split(", ") #拆解字串，如果有逗號，就分開

                        if sp_text[0] in Shop_name:
                            output_text = get_drink_item(sp_text)
                            #print("output_text: ", output_text)
                            #print(drink_category)

                        else:
                            output_text = "請按照步驟重新輸入位置資訊，我們會幫你找附近的飲料店喔~~"
                        
                        line_bot_api.reply_message(  # 輸入其他文字時，回復傳入的訊息文字
                            event.reply_token,
                            TextSendMessage(text = output_text)
                        )
                        
                        print("sp_text: ", sp_text[0])
                        #print(drink_category)

                    

                # 如果傳入的是位置訊息
                elif event.message.type == 'location':

                    # user的經緯度
                    user_latitude = event.message.latitude #緯度 24.多
                    user_longitude = event.message.longitude  #精度 121.多
                    
                    drinkShop = iDrink() #可得到爬蟲經緯度的結果。資料型態是coordinates。程式在scraper.py
                    # print("drinkShop ", drinkShop.scrape(), "\n user_latitude: ", user_latitude, " user_longitude: ", user_longitude) #檢查drinkShop是否有得到web的經緯度                   
                    
                    distance = [] #存所有距離的list
                    drinkShop_options.clear() # 重新存data

                    for shopname, branchshop, addr, ll, nn in drinkShop.scrape():
                        ShopName = shopname
                        BRANCH_SHOP = branchshop
                        address = addr
                        lat_try = ll
                        lon_try = nn

                        # 計算所有距離，存入distance[]
                        distance.append((haversine(user_latitude, user_longitude, lat_try, lon_try), BRANCH_SHOP, ShopName, address))
                        #print("d: ", haversine(user_latitude, user_longitude, lat_try, lon_try), "shop name: ", shopname) #檢查haversine是否有得到距離
                       
                    distance.sort() #距離由小到大排序
                    count=0 #用來看有沒有距離小於1公里的店家
                                        
                    #查看前8筆距離短的資料，如果距離小於1公里，就回傳。如果有回傳一筆就跳出回圈。
                    for i in range (0, 5):
                        if distance[i][0] < 1:
                            #print("店名: ", distance[i][2], " / 分店: ", distance[i][1], " / 距離: ", distance[i][0], " / 地址: ", distance[i][3])
                            
                            google_maps_link = generate_google_maps_link(distance[i][3])
                            #print("google_maps_link: ",google_maps_link)
                            
                            drinkShop_options.append({
                                'ShopName': distance[i][2],
                                'BRANCH_SHOP': distance[i][1],
                                'url': google_maps_link
                                }
                            )
                            count+=1

                        else:
                            print("Sorry~ 方圓一公里內沒有飲料店喔")
                            line_bot_api.reply_message(
                                event.reply_token,
                                TextSendMessage(text= "Sorry~ 方圓一公里內沒有飲料店喔")
                            )
                            break
                            
                    print("drinkShop_options: ", drinkShop_options)
                    if count > 0:
                        #右滑式選單，顯示飲料店選單
                        near_shop = send_near_shop()
                        line_bot_api.reply_message(
                            event.reply_token,
                            near_shop
                        )
                        count=0

                    
                            
                        
                        
        return HttpResponse()
        
    else:
        return HttpResponseBadRequest()





# 傳送user附近的飲料店
def send_near_shop():
    columns=[]
    for option in drinkShop_options:
        column = CarouselColumn(
            title = option['ShopName'],
            text = option['BRANCH_SHOP'],
            actions = [ #action最多只能添加三個
                MessageAction(
                label = '點我看菜單', #顯示在按鈕上的文字
                text = option['ShopName'] #顯示在聊天室的文字
                ),
                URIAction(
                    label = 'Google Map',
                    uri = option['url']
                )
            ]
        )
        columns.append(column)
        # 创建 CarouselTemplate，并指定 columns 参数为上述列表
        carousel_template = CarouselTemplate(columns=columns)
                        
        # 使用上述 CarouselTemplate 创建 TemplateSendMessage
        template_message = TemplateSendMessage(
            alt_text='CarouselTemplate',
            template=carousel_template
        )
    return template_message


#列印不重複的飲料類別
def get_unique_types(category):
    unique_types = []
    printed_types = set()

    for item in category:
        drink_type = item['type']
        if drink_type not in printed_types:
            unique_types.append({
                'type': drink_type
                })
            printed_types.add(drink_type)

    return unique_types

        






# 輸入地址產生Google Maps連結
def generate_google_maps_link(address):
    base_url = 'https://www.google.com/maps/search/?api=1'
    encoded_address = urllib.parse.quote(address)
    return f'{base_url}&query={encoded_address}'


# 計算兩點間的距離
def haversine(lat1, long1, lat2, long2):
    R = 6371  # 地球半徑(公里)
    def rad(x):
        return x * math.pi / 180

    dLat = rad(lat2 - lat1)
    dLong = rad(long2 - long1)

    a = math.sin(dLat / 2) * math.sin(dLat / 2) + \
        math.cos(rad(lat1)) * math.cos(rad(lat2)) * \
        math.sin(dLong / 2) * math.sin(dLong / 2)

    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))

    d = R * c

    return d

